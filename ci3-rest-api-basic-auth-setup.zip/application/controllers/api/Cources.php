<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/RestController.php';
class Cources extends RestController
{

    function __construct()
    {
        parent::__construct();
        // header('Content-Type:application/json');
        // header('Access-Control-Allow-Methods:POST,GET,PUT,DELETE');
    }

    public function index_post()
    {
        $this->response(array(
            "status" => 1,
            "message" => "Post",
            'data' => ''
        ), RestController::HTTP_OK);
    }
    public function index_get($id = NULL)
    {
        $this->response(array(
            "status" => 1,
            "message" => "get",
            'data' => ''
        ), RestController::HTTP_OK);
    }
}
